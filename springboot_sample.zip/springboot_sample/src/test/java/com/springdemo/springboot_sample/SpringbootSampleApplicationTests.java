package com.springdemo.springboot_sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
